// Bet controller

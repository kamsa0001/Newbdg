// Bet model

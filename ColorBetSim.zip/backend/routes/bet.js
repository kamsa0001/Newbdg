// Bet routes

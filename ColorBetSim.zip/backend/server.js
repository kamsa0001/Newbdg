// Entry point for backend

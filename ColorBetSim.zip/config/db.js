// MongoDB connection setup

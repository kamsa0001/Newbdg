// Middleware for JWT auth

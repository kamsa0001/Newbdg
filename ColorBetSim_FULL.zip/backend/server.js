
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const authRoutes = require('./routes/auth');
const betRoutes = require('./routes/bet');
const adminRoutes = require('./routes/admin');
const connectDB = require('../config/db');

const app = express();
const PORT = process.env.PORT || 5000;

// Connect to DB
connectDB();

// Middleware
app.use(cors());
app.use(express.json());

// Routes
app.use('/api/auth', authRoutes);
app.use('/api/bet', betRoutes);
app.use('/api/admin', adminRoutes);

app.get('/', (req, res) => {
    res.send('ColorBetSim API is running');
});

app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});

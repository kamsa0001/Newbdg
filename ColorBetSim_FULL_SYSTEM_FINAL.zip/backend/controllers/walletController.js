
const Wallet = require('../models/Wallet');

exports.getWalletHistory = async (req, res) => {
    try {
        const history = await Wallet.find({ userId: req.params.userId }).sort({ timestamp: -1 });
        res.json(history);
    } catch (err) {
        res.status(500).json({ msg: 'Failed to fetch wallet history' });
    }
};

exports.addWalletEntry = async (entry) => {
    try {
        const newEntry = new Wallet(entry);
        await newEntry.save();
    } catch (err) {
        console.error('Wallet save error:', err);
    }
};


const express = require('express');
const router = express.Router();
const { playDice } = require('../controllers/diceGameController');

router.post('/play', playDice);

module.exports = router;

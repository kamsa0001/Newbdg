
const express = require('express');
const router = express.Router();
const { playSlot } = require('../controllers/slotController');

router.post('/play', playSlot);

module.exports = router;

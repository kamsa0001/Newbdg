
const express = require('express');
const router = express.Router();
const { getWalletHistory } = require('../controllers/walletController');

router.get('/:userId', getWalletHistory);

module.exports = router;


exports.playDice = async (req, res) => {
    const { userId, betAmount, guess } = req.body;
    const roll = Math.floor(Math.random() * 6) + 1;
    const win = parseInt(guess) === roll;

    try {
        const User = require('../models/User');
        const user = await User.findById(userId);
        if (!user || user.balance < betAmount) {
            return res.status(400).json({ msg: 'Invalid balance or user' });
        }

        user.balance -= betAmount;
        if (win) user.balance += betAmount * 6; // win 6x
        await user.save();

        res.json({ roll, win, balance: user.balance });
    } catch (err) {
        res.status(500).json({ msg: 'Game error' });
    }
};

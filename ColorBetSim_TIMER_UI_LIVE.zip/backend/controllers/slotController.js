
const User = require('../models/User');
const { addWalletEntry } = require('./walletController');

exports.playSlot = async (req, res) => {
    const { userId, betAmount } = req.body;
    const reels = ['🍒', '🍋', '🔔', '⭐', '💎'];
    const spin = [reels[Math.floor(Math.random()*5)], reels[Math.floor(Math.random()*5)], reels[Math.floor(Math.random()*5)]];
    let win = 0;

    if (spin[0] === spin[1] && spin[1] === spin[2]) {
        win = betAmount * 5;
    } else if (spin[0] === spin[1] || spin[1] === spin[2] || spin[0] === spin[2]) {
        win = betAmount * 2;
    }

    try {
        const user = await User.findById(userId);
        if (!user || user.balance < betAmount) return res.status(400).json({ msg: 'Insufficient balance' });

        user.balance -= betAmount;
        await addWalletEntry({ userId, type: 'bet', amount: betAmount, description: 'Slot bet' });

        if (win > 0) {
            user.balance += win;
            await addWalletEntry({ userId, type: 'win', amount: win, description: 'Slot win' });
        }

        await user.save();
        res.json({ spin, win, balance: user.balance });
    } catch (err) {
        res.status(500).json({ msg: 'Slot error' });
    }
};


const mongoose = require('mongoose');

const UserSchema = new mongoose.Schema({
    username: { type: String, required: true, unique: true },
    password: { type: String, required: true },
    balance: { type: Number, default: 1000 },
    isAdmin: { type: Boolean, default: false },
    referralCode: { type: String, unique: true },
    referredBy: { type: String }
});

// Generate unique referral code on new user creation
UserSchema.pre('save', function (next) {
    if (!this.referralCode) {
        this.referralCode = 'REF' + Math.random().toString(36).substr(2, 8).toUpperCase();
    }
    next();
});

module.exports = mongoose.model('User', UserSchema);

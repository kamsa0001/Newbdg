
const express = require('express');
const router = express.Router();
const User = require('../models/User');
const { addWalletEntry } = require('../controllers/walletController');

router.post('/', async (req, res) => {
    const { userId, amount } = req.body;
    try {
        const user = await User.findById(userId);
        if (!user) return res.status(404).json({ msg: 'User not found' });

        user.balance += amount;
        await user.save();
        await addWalletEntry({ userId, type: 'deposit', amount, description: 'Manual point purchase' });

        res.json({ msg: `✅ Added ${amount} points to your balance.` });
    } catch (err) {
        res.status(500).json({ msg: 'Error processing purchase' });
    }
});

module.exports = router;

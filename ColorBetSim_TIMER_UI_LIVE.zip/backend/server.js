
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const path = require('path');
const authRoutes = require('./routes/auth');
const betRoutes = require('./routes/bet');
const adminRoutes = require('./routes/admin');
const diceRoutes = require('./routes/dice');
const slotRoutes = require('./routes/slot');
const walletRoutes = require('./routes/wallet');
const buyRoutes = require('./routes/buy');
const connectDB = require('../config/db');

const http = require('http');
const { Server } = require('socket.io');
const { startBettingTimer, currentRound } = require('./timer');
const app = express();
const PORT = process.env.PORT || 5000;

// Connect to DB
connectDB();

// Middleware
app.use(cors());
app.use(express.json());

// Serve static files
app.use(express.static(path.join(__dirname, '../frontend')));

// API Routes
app.use('/api/auth', authRoutes);
app.use('/api/bet', betRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api/dice', diceRoutes);
app.use('/api/slot', slotRoutes);
app.use('/api/wallet', walletRoutes);
app.use('/api/buy', buyRoutes);

// Route for homepage
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, '../frontend/index.html'));
});

// Route for admin panel
app.get('/admin', (req, res) => {
    res.sendFile(path.join(__dirname, '../frontend/admin.html'));
});

// Route for dice game
app.get('/dice', (req, res) => {
    res.sendFile(path.join(__dirname, '../frontend/dice.html'));
});


app.get('/teenpatti', (req, res) => {
    res.sendFile(path.join(__dirname, '../frontend/teenpatti.html'));
});

app.get('/slot', (req, res) => {
    res.sendFile(path.join(__dirname, '../frontend/slot.html'));
});

app.get('/buy', (req, res) => {
    res.sendFile(path.join(__dirname, '../frontend/buy.html'));
});

app.get('/wallet', (req, res) => {
    res.sendFile(path.join(__dirname, '../frontend/wallet.html'));
});

const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });

startBettingTimer(io);

server.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});


let currentRound = {
    id: 1,
    timeLeft: 30,
    status: 'betting',
    result: null
};

function startBettingTimer(io) {
    setInterval(() => {
        if (currentRound.timeLeft > 0) {
            currentRound.timeLeft--;
        } else {
            currentRound.status = 'closed';
            currentRound.result = ['Red', 'Green', 'Blue', 'Yellow'][Math.floor(Math.random() * 4)];
            io.emit('round-ended', currentRound);

            // Start new round after 5 seconds
            setTimeout(() => {
                currentRound = {
                    id: currentRound.id + 1,
                    timeLeft: 30,
                    status: 'betting',
                    result: null
                };
                io.emit('round-started', currentRound);
            }, 5000);
        }
    }, 1000);
}

module.exports = { currentRound, startBettingTimer };
